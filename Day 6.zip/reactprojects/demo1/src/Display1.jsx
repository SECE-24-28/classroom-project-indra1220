function Display1(){
    var name="demo"
    HTMLFormControlsCollection.log("im inside the display1",{name})
    function changeName(d){
        var name=dconsole.log("im inside the display1",{name})
    }
    return(
        <>
        <h1>im from display1{name}</h1>

<button onClick={()=>{changeName('not demo')}}>click here!!!!</button>    
   </>
    )
}
export default Display1  