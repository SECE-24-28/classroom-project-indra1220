/*const express=require('express')
const app=express()
const bodyParser=require('body-parser')
const exhbs=require('express-handlebars')
const dbo=require('./db')



app.engine('hbs',exhbs.engine(
    {layoutsDir:'viewsfold/',
        defaultLayout:"main",
        extname:"hbs"}))

app.set('view engine','hbs')
app.set('views','viewsfold')

app.use(bodyParser.urlencoded({extended:true}))

app.post('/store_book',async(req,res)=>{
    let database = await dbo.getDataBase()
    const collection=database.collection('books')
    let bookdata={title:req.body.title,author:req.body.author}
    await collection.insertOne(bookdata)
    return res.redirect('/?status=1')
})


 app.get('/',async(req,res)=>{
    let database=await dbo.getDataBase()
    const collection=database.collection('books')
    const cursor=collection.find({})
    let mydata=await cursor.toArray()
    let message=''

 switch(req.query.status ){
    case '1':
        message="inserted successfully"
        break;

        default:
            break;
}
res.render('main',mydata)
})
app.listen(8000,()=>{console.log('listening to 8000')})*/

const express = require('express');
const app = express();
const exhbs = require('express-handlebars');
const dbo = require('./db');

app.engine('hbs', exhbs.engine({
    layoutsDir: 'viewsfold/',
    defaultLayout: "main",
    extname: "hbs"
}));

app.set('view engine', 'hbs');
app.set('views', 'viewsfold');

app.use(express.urlencoded({ extended: true }));

app.post('/store_book',async(req,res)=>{
    let database = await dbo.getDataBase()
    const collection=database.collection('books')
    let bookdata={title:req.body.title,author:req.body.author}
    await collection.insertOne(bookdata)
    return res.redirect('/?status=1')
})

app.get('/', async (req, res) => {
    let database = await dbo.getDataBase();
    const collection = database.collection('books');
    let mydata = await collection.find({}).toArray();

    let message = "";
    switch (req.query.status) {
        case '1':
            message = "inserted successfully";
            break;
    }

    res.render('main', { message, mydata });
});

app.listen(8000, () => {
    console.log('listening to 8000');
});

